import java.util.*;

public class CodeSoftTask2 {
    public static void main(String args[]) {
        int Java, advanceJava, dataAnalytics, compilerConstruction, totalMarks, averagePercentage, Grade;
        ;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Marks Obtain in Java out of 100");
        Java = sc.nextInt();
        System.out.println("Enter Marks Obtain in Advance Java out of 100");
        advanceJava = sc.nextInt();
        System.out.println("Enter Marks Obtain in Data Analytics out of 100 ");
        dataAnalytics = sc.nextInt();
        System.out.println("Enter Marks Obtain in Compiler Construction out of 100");
        compilerConstruction = sc.nextInt();
        if (Java > 100 || advanceJava > 100 || dataAnalytics > 100 || compilerConstruction > 100) {
            System.out.println("Please Enter the Marks out of 100 Inputed Marks are Above 100");
        } else {
            totalMarks = Java + advanceJava + dataAnalytics + compilerConstruction;
            averagePercentage = totalMarks / 4;
            System.out.println(totalMarks);
            System.out.println(averagePercentage);
            if (averagePercentage > 90) {
                System.out.println("Grade A+");
            } else if (80 < averagePercentage && averagePercentage < 90) {
                System.out.println("Grade A");
            } else if (70 < averagePercentage && averagePercentage < 80) {
                System.out.println("Grade B");
            } else if (50 < averagePercentage && averagePercentage < 70) {
                System.out.println("Grade C");
            } else if (35 <= averagePercentage) {
                System.out.println("Grade D");
            } else {
                System.out.println("Fail");
            }


        }
    }
}
